<?php
declare(strict_types=1);

namespace SouqLink;

use PDO;
use PDOException;

final class Database
{
    private static ?PDO $instance = null;
    private static ?array $localConfiguration = null;

    public static function connection(): PDO
    {
        if (self::$instance instanceof PDO) return self::$instance;
        $host = self::environment('DB_HOST');
        $port = self::environment('DB_PORT', '3306');
        $database = self::environment('DB_DATABASE');
        $username = self::environment('DB_USERNAME');
        $password = self::environment('DB_PASSWORD');
        if (!$host || !$database || !$username) throw new PDOException('Database environment is incomplete.');
        self::$instance = new PDO("mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4", $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        self::$instance->exec('SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci');
        // Store all server-generated timestamps in UTC; Flutter converts them to device local time.
        self::$instance->exec("SET time_zone = '+00:00'");
        return self::$instance;
    }

    public static function environment(string $name, ?string $default = null): ?string
    {
        $value = getenv($name);
        if ($value !== false && $value !== '') return $value;

        if (self::$localConfiguration === null) {
            $path = dirname(__DIR__) . '/config.local.php';
            self::$localConfiguration = is_file($path) ? require $path : [];
        }
        $configured = self::$localConfiguration[$name] ?? null;
        return is_string($configured) && $configured !== '' ? $configured : $default;
    }
}
